
% Nonlinear derivative function for Example 1
% fzero() computes sqrt(R)
% For given x, returns d

function d = dSquareRootdx( x )

d = 2.*x;

end

