function u = dexample1( x )

u = 2*x;

end
