function u = example1( x )

u = x.^2 - 2;

end
