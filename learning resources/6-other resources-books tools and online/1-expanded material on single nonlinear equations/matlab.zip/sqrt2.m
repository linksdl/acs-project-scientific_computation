function f = sqrt2(x)

% function f = sqrt2(x)
%
% Evaluate the nonlinear function for finding the square root of R.
%
% ARGUMENTS:  x   the point at which to evaluate
%
% RETURNS:    f   the value of the function at x


% Set R for evaluating sqrt(2).
  R = 2.0;
% Evaluate the function.
  f = x*x - R;
