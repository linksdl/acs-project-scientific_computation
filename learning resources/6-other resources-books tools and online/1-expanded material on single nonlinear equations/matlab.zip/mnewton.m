function [x,f] = mnewton(fnon,x0,tol)

% function [x,f] = mnewton(fnon,x0,tol)
%
% Use a modified Newton method to solve the nonlinear equation fnon(x)=0,
% starting from the estimate x0.
%
% ARGUMENTS:  fnon  handle for the nonlinear function
%             x0    the initial estimate
%             tol   convergence tolerance
%
% RETURNS:    x     the computed root
%             f     the function value at that root

% Select a suitable value for dx.
dx = sqrt(eps);

% Print column headings for output.
fprintf('      x            f(x)\n')

% Set the initial estimate for the root and evaluate the function there.
x = x0;
f = feval(fnon,x);

% Print the estimate and function value.
fprintf(' %12.6f %12.6f\n',x,f)

% Repeat the Newton iteration until the magnitude of the function value is
% less than tol.
while abs(f) > tol
  % Apply one iteration of Newton's method and evaluate the function at the
  % new estimate.
  x = x - (dx * f)/(feval(fnon,x+dx)-f);
  f = feval(fnon,x);
 
  % Print the new estimate and function value.
  fprintf(' %12.6f %12.6f\n',x,f)
end
