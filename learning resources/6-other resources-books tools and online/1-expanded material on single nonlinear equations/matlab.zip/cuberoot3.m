function f = cuberoot3(x)

% function f = cuberoot3(x)
%
% Evaluate the nonlinear function for finding the cube root of R.
%
% ARGUMENTS:  x   the point at which to evaluate
%
% RETURNS:    f   the value of the function at x


% Set R for evaluating sqrt(2).
  R = 3.0;
% Evaluate the function.
  f = x^3 - R;
