function f = compound(n)

% function f = compound(n)
%
% Evaluate the nonlinear function for finding the number of months required
% to repay a mortgage of P pounds at a repayment of M pounds per month and
% an annual interest rate of r percent.
%
% ARGUMENTS:  n   the point at which to evaluate the function
%
% RETURNS:    f   the value of the function at n


% Set P, M and r.
  P = 150000;
  M = 1000;
  r = 5.0;
% Evaluate the function.
  i = r/1200;
  f = M - P * ( i * (1+i)^n ) / ( (1+i)^n - 1 );
