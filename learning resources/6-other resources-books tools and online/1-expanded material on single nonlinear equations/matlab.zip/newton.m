function [x,f] = newton(fnon,dfnon,x0,tol)

% function [x,f] = newton(fnon,dfnon,x0,tol)
%
% Use Newton's method to find the root of the nonlinear equation fnon(x)=0,
% with derivative dfnon(x) and starting from the estimate x0.
%
% ARGUMENTS:  fnon  handle for the nonlinear function
%             dfnon handle for the derivative of the nonlinear function
%             x0    the initial estimate
%             tol   convergence tolerance
%
% RETURNS:    x     the computed root
%             f     the function value at that root


% Print column headings for output.
fprintf('      x            f(x)\n')

% Set the initial estimate for the root and evaluate the function there.
  x = x0;
  f = feval(fnon,x);

% Print the estimate and function value.
fprintf(' %12.6f %12.6f\n',x,f)

% Repeat the Newton iteration until the magnitude of the function value is
% less than tol.
while abs(f) > tol
  % Apply one iteration of Newton's method and evaluate the function at the
  % new estimate.
  x = x - f/feval(dfnon,x);
  f = feval(fnon,x);
 
  % Print the new estimate and function value.
  fprintf(' %12.6f %12.6f\n',x,f)
end
