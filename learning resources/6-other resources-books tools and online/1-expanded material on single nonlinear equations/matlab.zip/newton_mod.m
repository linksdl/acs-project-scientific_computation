function [x,f] = newton(fnon,dfnon,x0,tol)

% function [x,f] = newton(fnon,dfnon,x0,tol)
%
% Use Newton's method to find the root of the nonlinear equation fnon(x)=0,
% with derivative dfnon(x) and starting from the estimate x0. Note that
% this version also calculates the error for the special case where the
% solution is known to be the cube root of 3.
%
% ARGUMENTS:  fnon  handle for the nonlinear function
%             dfnon handle for the derivative of the nonlinear function
%             x0    the initial estimate
%             tol   convergence tolerance
%
% RETURNS:    x     the computed root
%             f     the function value at that root


% Print column headings for output.
fprintf('          x                    f(x)                  error\n')

% Set the initial estimate for the root and evaluate the function there.
  x = x0;
  f = feval(fnon,x);
  %error = abs(x-sqrt(2));
  error = abs(x-3^(1/3));

% Print the estimate and function value.
fprintf(' %20.14f %20.14f %20.14f\n',x,f,error)

% Repeat the Newton iteration until the magnitude of the function value is
% less than tol.
while abs(f) > tol
  % Apply one iteration of Newton's method and evaluate the function at the
  % new estimate.
  x = x - f/feval(dfnon,x);
  f = feval(fnon,x);
  olderror = error;
  %error = abs(x-sqrt(2));
  error = abs(x-3^(1/3));
  % Print the new estimate and function value.
  fprintf(' %20.14f %20.14f %20.14f %20.14f\n',x,f,error,error/olderror^2)
end
