function f = naca0012(x)

% function f = naca0012(x)
%
% Evaluate the nonlinear function for the naca0012 aerofoil example.
%
% ARGUMENTS:  x   the point at which to evaluate
%
% RETURNS:    f   the value of the function at x


% Set the required thickness at the intersection to be 0.1.
  t = 0.1;
% Evaluate the function.
  yp = -0.1015*x.^4 + 0.2843*x.^3 - 0.3516*x.^2 - 0.126*x + 0.2969*sqrt(x);
  f = yp - 0.5*t;
