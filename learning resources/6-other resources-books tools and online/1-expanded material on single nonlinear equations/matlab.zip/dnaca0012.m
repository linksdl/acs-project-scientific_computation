function f = dnaca0012(x)

% function f = dnaca0012(x)
%
% Evaluate the derivative of the function for the naca0012 aerofoil example.
%
% ARGUMENTS:  x   the point at which to evaluate
%
% RETURNS:    f   the value of the derivative at x


% Evaluate the derivative.
  dy = -4*0.1015*x.^3 + 3*0.2843*x.^2 - 2*0.3516*x - 0.126 + 0.2969*(1/2)*x.^(-1/2);
  f = dy;
