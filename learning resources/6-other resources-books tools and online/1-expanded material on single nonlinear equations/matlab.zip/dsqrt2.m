function f = dsqrt2(x)

% function f = dsqrt2(x)
%
% Evaluate the derivative of the function for finding the square root of R.
%
% ARGUMENTS:  x   the point at which to evaluate
%
% RETURNS:    f   the value of the derivative at x


% Set R for evaluating sqrt(2).
  R = 2.0;
% Evaluate the derivative.
  f = 2.0*x;
