function [x,f] = bisection(fnon,xL,xR,tol)

% function [x,f] = bisection(fnon,xL,xR,tol)
%
% Use the basic bisection method to find the root of the nonlinear equation
% fnon(x)=0 within the bracket [xL,xR].
%
% ARGUMENTS:  fnon  the nonlinear function
%             xL, xR
%                   the initial bracket [xL,xR], for which f(xL)*f(xR)<0
%             tol   convergence tolerance
%
% RETURNS:    x     the computed root
%             f     the function value at that root


% Find the function values on the initial bracket.
fL = feval(fnon,xL);
fR = feval(fnon,xR);

if (fL * fR > 0)
  fprintf('Warning! The input values do not provide a bracket.')
else
  % Print column headings for output.
  fprintf(' (    xL,          f(xL)    ) (    xR,          f(xR)    )\n')

  % Repeat the bisection iteration until the bracket width is less than tol.
  while abs(xR-xL) > tol
    % Print the current bracket and the function values at each end.
    fprintf(' (%12.8f, %12.8f) (%12.8f, %12.8f)\n',xL,feval(fnon,xL),xR,feval(fnon,xR));
   
    % Find the midpoint of the bracket and evaluate the function there.
    xC = (xL+xR)/2;
    fC = feval(fnon,xC);
 
    % Choose the new bracket to contain the root.
    if fL*fC <= 0
      % The root is to the left of C, so set R=C.
      xR = xC;
      fR = fC;
    else  
      % The root is to the right of C, so set L=C.
      xL = xC;
      fL = fC;
    end  
  end  
end  

% Set final estimate to be the midpoint value.
x = (xL+xR)/2;
f = (fL+fR)/2;
