% runfzero.m
%
% Use the fzero function to solve a number of nonlinear equations, as
% illustrated in lecture 17.

% Solve "x^2 -2 = 0" with an initial iterate of 1.0 and using the "disp"
% option with value "iter" to display output after each iteration.
fprintf('Solving x^2-2=0 with an initial iterate of 1.0...\n')
fzero('sqrt2',1,optimset('disp','iter'))

fprintf('Press any key to continue...\n')
pause

% Solve "x^2 -2 = 0" with an initial bracket of (0,1) and using the "disp"
% option with value "iter" to display output after each iteration.
fprintf('Solving x^2-2=0 with an initial interval of (1,2)...\n')
fzero('sqrt2',[1,2],optimset('disp','iter'))

fprintf('Press any key to continue...\n')
pause

% Solve the compound interest problem with an initial bracket of (200,300)
% using the "disp" option with value "iter" to display output after each
% iteration, and the "TolX" option with value "1.0e-3" to define the
% relative stopping tolerance.
fprintf('Solving the compund interest example with an initial interval\n')
fprintf('of (200,300)...\n')
fzero('compound',[200,300],optimset('disp','iter','TolX',1.0e-3))

fprintf('Press any key to continue...\n')
pause

% Solve the NACA0012 example problem with an initial bracket of (0.5,1)
% and using the "disp" % option with value "iter" to display output after
% each iteration.
fprintf('Solving the NACA0012 example with an initial interval of (0.5,1)\n')
fzero('naca0012',[0.5,1],optimset('disp','iter'))

fprintf('Press any key to continue...\n')
pause

% Solve the NACA0012 example problem with an initial bracket of (0.0.5)
% and using the "disp" % option with value "iter" to display output after
% each iteration.
fprintf('Solving the NACA0012 example with an initial interval of (0,0.5)\n')
fzero('naca0012',[0,0.5],optimset('disp','iter'))