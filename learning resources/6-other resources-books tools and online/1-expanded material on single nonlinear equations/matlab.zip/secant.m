function [x,f] = secant(fnon,x0,x1,tol)

% function [x,f] = secant(fnon,x0,x1,tol)
%
% Use the secant method to find the root of the nonlinear equation fnon(x)=0
% starting from the estimates x0 and x1.
%
% ARGUMENTS:  fnon  handle for the nonlinear function
%             x0    the initial estimate
%             x1    the second estimate
%             tol   convergence tolerance
%
% RETURNS:    x     the computed root
%             f     the function value at that root


% Print column headings for output.
fprintf('          x                    f(x)\n')

% Set the initial estimate for the root and evaluate the function there.
  f0 = feval(fnon,x0);
  f1 = feval(fnon,x1);

% Print the estimate and function value.
fprintf(' %20.14f %20.14f\n',x0,f0)
fprintf(' %20.14f %20.14f\n',x1,f1)

% Repeat the secant iteration until the magnitude of the function value is
% less than tol.
while abs(f1) > tol
  % Apply one iteration of the secant method and evaluate the function at the
  % new estimate.
  x2 = x1 - f1*(x1-x0)/(f1-f0);
  f2 = feval(fnon,x2);
  % Print the new estimate and function value.
  fprintf(' %20.14f %20.14f\n',x2,f2)
  x0 = x1;
  f0 = f1;
  x1 = x2;
  f1 = f2;
end

x = x1;
f = f1;
