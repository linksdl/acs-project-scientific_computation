function f = dlin(x)

% function f = dlin(x)
%
% Evaluate the derivative of the function for the double root test case.
%
% ARGUMENTS:  x   the point at which to evaluate
%
% RETURNS:    f   the value of the derivative at x


% Evaluate the derivative.
  f = 2*(x-1);
