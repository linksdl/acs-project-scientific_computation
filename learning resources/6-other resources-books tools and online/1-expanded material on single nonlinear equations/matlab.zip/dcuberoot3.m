function f = dcuberoot3(x)

% function f = dcuberoot3(x)
%
% Evaluate the derivative of the function for finding the cube root of R.
%
% ARGUMENTS:  x   the point at which to evaluate
%
% RETURNS:    f   the value of the derivative at x


% Set R for evaluating sqrt(2).
  R = 3.0;
% Evaluate the derivative.
  f = 3.0*x^2;
