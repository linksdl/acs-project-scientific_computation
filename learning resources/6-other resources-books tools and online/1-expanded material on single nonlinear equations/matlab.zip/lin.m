function f = lin(x)

% function f = lin(x)
%
% Evaluate the nonlinear function for the double root test case.
%
% ARGUMENTS:  x   the point at which to evaluate
%
% RETURNS:    f   the value of the function at x


% Evaluate the function.
  f = (x-1).^2;
